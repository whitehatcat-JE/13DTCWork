public class Simulate {
    public static void main(String[] args) {
        Arena a = new Arena();

        a.fight();
    }
}